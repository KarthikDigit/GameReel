package com.instaclone.dashboard.home;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.request.RequestOptions;
import com.instaclone.R;
import com.instaclone.helper.VerticalSpacingItemDecorator;

import java.util.ArrayList;
import java.util.Arrays;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {


    @BindView(R.id.homeListView)
    VideoPlayerRecyclerView homeListView;

//    private HomeFeedAdapter mHomeFeedAdapter;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        ButterKnife.bind(this, view);

//        mHomeFeedAdapter = new HomeFeedAdapter();

//        homeListView.setLayoutManager(new LinearLayoutManager(getContext()));
//        homeListView.setAdapter(mHomeFeedAdapter);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        homeListView.setLayoutManager(layoutManager);
        VerticalSpacingItemDecorator itemDecorator = new VerticalSpacingItemDecorator(10);
        homeListView.addItemDecoration(itemDecorator);

        ArrayList<MediaObject> mediaObjects = new ArrayList<MediaObject>(Arrays.asList(Resources.MEDIA_OBJECTS));
        homeListView.setMediaObjects(mediaObjects);
        VideoPlayerRecyclerAdapter adapter = new VideoPlayerRecyclerAdapter(mediaObjects, initGlide());
        homeListView.setAdapter(adapter);

        return view;

    }

    private RequestManager initGlide() {
        RequestOptions options = new RequestOptions()
                .placeholder(R.drawable.white_background)
                .error(R.drawable.white_background);

        return Glide.with(getContext())
                .setDefaultRequestOptions(options);
    }

    @Override
    public void onDestroy() {
        if (homeListView != null)
            homeListView.releasePlayer();
        super.onDestroy();
    }

}
